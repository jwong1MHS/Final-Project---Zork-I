-----------------------------------------------------------------

 DOS Games Loader for MacOS prepared by GamesNostalgia.com

 If you like what we do, support us on Patreon:
 
	https://www.patreon.com/gamesnostalgia
 
 or with a donation:

	http://gamesnostalgia.com/donate
 
-----------------------------------------------------------------

 USEFUL KEYS:

 fn+ctrl+F11  = Decrease speed
 
 fn+ctrl+F12  = Increase speed
 
 Alt+Enter    = Switch to/from Full Screen
 
 fn+ctrl+F9   = Quit  (or Cmd+Q)

-----------------------------------------------------------------

 Thanks to DOSBox http://www.dosbox.com/ for the emulator

 Please go to http://gamesnostalgia.com for more retrogames